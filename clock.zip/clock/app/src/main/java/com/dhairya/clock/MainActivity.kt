package com.dhairya.clock

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextClock
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tclock=findViewById<TextClock>(R.id.textclock)
        val tclock1=findViewById<TextClock>(R.id.textclock1)
        tclock.format12Hour=null
        tclock.format24Hour="HH:mm:ss"
        tclock1.format12Hour=null
        tclock1.format24Hour="MMM dd,yyyy"

        val bottomnavbar=findViewById<BottomNavigationView>(R.id.bottomnavbar)
        bottomnavbar.selectedItemId=R.id.alarm
        bottomnavbar.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.timer -> {
                    Intent(this, timerActivity::class.java).apply {
                        startActivity(this)
                    }

                    return@setOnItemSelectedListener true
                }
                R.id.stopwatch -> {
                    Intent(this, stopwatchActivity::class.java).apply {
                        startActivity(this)
                    }

                    return@setOnItemSelectedListener true
                }
                else -> {
                    Intent(this, MainActivity::class.java).apply {
                        startActivity(this)
                    }
                    return@setOnItemSelectedListener true
                }
            }
        }




    }
}